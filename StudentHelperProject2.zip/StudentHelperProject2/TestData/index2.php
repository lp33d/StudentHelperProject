<!DOCTYPE html>
<head>
<title>Study room creater</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style>
li {listt-style: none;}
</style>
</head>
<body>
<h2>Enter information regarding studyRoom</h2>
<ul>
<form name="insert" action="insert.php" method="POST" >
<li>StudyGroup Name:</li><li><input type="text" name="StudyName" /></li>
<li>room:</li><li><input type="text" name="room_name" /></li>
<li>Projector:</li><li><input type="text" name="projector" /></li>
<li>number_Of_students:</li><li><input type="text" name="numOfStud" /></li>
<li>Date:</li><li><input type="text" name="date" /></li>
<li>Time (Only for 1 hour):</li><li><input type="text" name="time" /></li>
<li><input type="submit" /></li>
</form>
</ul>
</body>
</html>
<?php
$db = pg_connect("host=localhost port=5432 dbname=studyGroup user=postgres password=password");
$query = "INSERT INTO studyRoom VALUES ('$_POST[StudyName]',
'$_POST[room]','$_POST[no_students]','$_POST[date]',
'$_POST[time]')";
$result = pg_query($query); 
?>
