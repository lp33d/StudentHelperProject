# StudentHelperProject
Student help webpage
Hi Team, we have both mine and Alexs websites, we need to pull them together to have only one. We has two because 
Alexs site is already suited to a mobile device and has a form validation and mine has the correct images and pages. 
trying to access the database, which i a still trying to implement.
I will create the lecturer website. Tomorrow i have a toutrial in how to implement a website with jack my database teacher.
I should be able to link the two after this. 
.Finish google maps
.Add a lecturer GUI
.Implement Database
.Learn how to make a recored video
.Test software
.If your still leanring github, please make your first pull request and commit
.Any issue please message through github or facebook
>Got until friday to get most of this protype finished

I'm struggling to get my php server to load up my page
