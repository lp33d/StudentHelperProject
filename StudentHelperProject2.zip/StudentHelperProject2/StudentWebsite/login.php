<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Login</title>
	<link href="stylesheet.css" rel="stylesheet" type="text/css">
	<script src="Javascript/JS.js">
	</script>
</head>
<body>
	<section id="externalWrapper">
		<h2 style="display:none;">.</h2>
		<nav>
		<ul>
				<li>
					<a href="index.php" id="logo">Student Helper</a>
				</li>
				<li>
					<a href="createGroup.php">Create Group</a>
				</li>
				<li>
					<a class="active" href="joinGroup.php">Join Group</a>
				</li>
				<li>
					<a href="routeFinder.php">Route Finder</a>
				</li>
				<li>
					<a href="courseworkDropoff.php">Coursework Dropoff</a>
				</li>
			</ul>
		</nav>
		<section id="internalWrapper">
			<div class="row cf">
				<div class="half">
					<form action="php/login.php" method="post">
						<div class="row cf">
							<div class="full">
								<h2>Login</h2>
							</div>
						</div>
						<div class="row cf">
							<div class="half">
								<p class="inputName">Email address:</p>
							</div>
							<div class="half">
								<input id="email" name="email" required="" type="email">
							</div>
						</div>
						<div class="row cf">
							<div class="half">
								<p class="inputName">Password:</p>
							</div>
							<div class="half">
								<input id="password" name="password" required="" type="password">
							</div>
						</div>
						<div class="row cf">
							<div class="threeQuarters">
								<a class="button" href="joinGroup.html">Forgot logon credentials</a>
							</div>
							<div><a class="button2" href="mainPage.php"></a>
							</div>
						</div>
					</form>
				</div>
				<div class="half">
					<form>
						<div class="row cf">
							<div class="full">
								<h2>Sign up</h2>
							</div>
						</div>
						<div class="row cf">
							<div class="full">
								<a class="button" href="signUp.html">New user?</a>
							</div>
						</div>
					</form>
				</div>
			</div>
			<footer>
				<a href="http://validator.w3.org/check?uri=referer">Valid HTML 5</a>
				<a href="mailto:support@outdoorcentremanager.co.uk">Support</a>
				<a href="http://jigsaw.w3.org/css-validator/check/referer">
					<img style="border:0;width:88px;height:31px"
						src="http://jigsaw.w3.org/css-validator/images/vcss"
						alt="Valid CSS!" />
				</a>
			</footer>
		</section>
	</section>
</body>
</html>