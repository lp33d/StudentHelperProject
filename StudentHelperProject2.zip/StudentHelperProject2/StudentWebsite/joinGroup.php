<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Join Group</title>
	<link href="stylesheet.css" rel="stylesheet" type="text/css">
	<!--<script src="Javascript/JS.js">-->
	</script>
</head>
<body>
	<section id="externalWrapper">
	
		<h2 style="display:none;">.</h2>
		<nav>
			<ul>
				<li>
					<a href="index.php" id="logo">Student Helper</a>
				</li>
				<li>
					<a href="createGroup.php">Create Group</a>
				</li>
				<li>
					<a class="active" href="joinGroup.php">Join Group</a>
				</li>
				<li>
					<a href="routeFinder.php">Route Finder</a>
				</li>
				<li>
					<a href="courseworkDropoff.php">Coursework Dropoff</a>
				</li>
			</ul>
		</nav>
		<section id="internalWrapper">
		
			<div class="row cf">
			
				<div class="half">
					   <ul>
		<li> 
			<img src="St_Images/studyGroupExample2.gif" alt="" height="150" width="200"  />
			
			
		</li>
		<li> 
			<img src="St_Images/studyGroupExample3.gif" alt="" height="150" width="200" />
			
			
		</li>
	</ul> 
					<div class="row cf">
						<div class="full">
							<a href="joinGroup.html">Search by subject</a>
						</div>
					</div>															<?php
$db = pg_connect("host=localhost port=5432 dbname=studyGroup user=postgres password=password");
$result = pg_query($db, "SELECT * FROM room where study_name = '$_POST[studyName]'");
$row = pg_fetch_assoc($result);
if (isset($_POST['submit']))
{
echo "<ul>
<form name='update' action='joinGroup.php' method='POST' >
<li>studyGroup name:</li><li><input type='text' name='studyName_updated' value='$row[study_name]'  /></li>
<li>room:</li><li><input type='text' name='room_name_updated' value='$row[room_name]' /></li>
<li>Projector:</li><li><input type='text' name='projector_updated' value='$row[projector]' /></li>   
<li>Date :</li><li><input type='text' name='date_updated' value='$row[date]' /></li>
<li>Time:</li><li><input type='text' name='time_updated' value='$row[time]' /></li>
<li><input type='submit' name='new' /></li>
  </form>
</ul>";
}
if (isset($_POST['new']))
{
$result1 = pg_query($db, "UPDATE room SET study_name = '$_POST[studyName_updated]', study_name = '$_POST[studyName_updated]', 
projector = '$_POST[projector_updated]', projector = '$_POST[projector_updated]',date = '$_POST[date_updated]',
time = '$_POST[time_updated]'");
if (!$result1)
{
echo "Update failed!!";
} else
{
echo "Update successfull;";
}
}
?>
					<div class="row cf">
						<div class="half">
							<p>The image above is how</p>
																																											<form name="display" action="joinGroup.php" method="POST" >
<li>Study Room Name:</li><li><input type="text" name="studyName" /></li>
<li><input type="submit" name="submit" /></li>
</form>	
						</div>
						<div class="half">
							<p>The final join group will be displayed</p>
	
						</div>
					</div>

					<div class="row cf">
						<div class="half">
							
							
	
						</div>
						<div class="half">
							

						</div>
					</div>
				</div>
			</div>
			<div class="row cf">	
				

			</div>


			
		</section>

	</section>
	<footer>
				<a href="http://validator.w3.org/check?uri=referer">Valid HTML 5</a>
				<a href="mailto:support@outdoorcentremanager.co.uk">Support</a>
				<a href="http://jigsaw.w3.org/css-validator/check/referer">
					<img style="border:0;width:88px;height:31px"
						src="http://jigsaw.w3.org/css-validator/images/vcss"
						alt="Valid CSS!" />
				</a>
			</footer>
</body>
</html>
