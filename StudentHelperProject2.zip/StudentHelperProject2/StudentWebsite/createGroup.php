<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Create Group</title>
	<link href="stylesheet.css" rel="stylesheet" type="text/css">
	<!--<script src="Javascript/JS.js">-->
	</script>
</head>
<body>
	<section id="externalWrapper">
		<h2 style="display:none;">.</h2>
		<nav>
			<ul>
				<li>
					<a href="index.php" id="logo">Student Helper</a>
				</li>
				<li>
					<a href="createGroup.php">Create Group</a>
				</li>
				<li>
					<a class="active" href="joinGroup.php">Join Group</a>
				</li>
				<li>
					<a href="routeFinder.php">Route Finder</a>
				</li>
				<li>
					<a href="courseworkDropoff.php">Coursework Dropoff</a>
				</li>
			</ul>
		</nav>
		<section id="internalWrapper">
			<div class="row cf">
				<div class="half">
					<div class="row cf">
						<div class="full">
							<a href="createGroup.html">Create Group</a>
						</div>
					</div>
					<div class="row cf">
						<div class="half">
							<p>Fill in details to create group</p>
						</div>
						<div class="half">
							
						</div>
					</div>
					<div class="row cf">
						<div class="half">
							
						</div>
						<div class="half">
							
						</div>
					</div>
				</div>
			
			</div>
			<div class="row cf">	
			
			
			</div>
			
			<ul>
<form name="createGroup" action="createGroup.php" method="POST" >
<li>StudyGroup Name:</li><li><input type="text" name="StudyName" /></li>
<li>Subject:</li><li><input type="text" name="room_name" /></li>
<li>Projector:</li><li><input type="text" name="projector" /></li>
<li>Date:</li><li><input type="text" name="date" /></li>
<li>Time (Only for 1 hour):</li><li><input type="text" name="time" /></li>
<li><input type="submit" /></li>
</form>
</ul>
		</section>
		
	</section>
	<footer>
				<a href="http://validator.w3.org/check?uri=referer">Valid HTML 5</a>
				<a href="mailto:support@outdoorcentremanager.co.uk">Support</a>
				<a href="http://jigsaw.w3.org/css-validator/check/referer">
					<img style="border:0;width:88px;height:31px"
						src="http://jigsaw.w3.org/css-validator/images/vcss"
						alt="Valid CSS!" />
				</a>
			</footer>
</body>
</html>
<?php
$db = pg_connect("host=localhost port=5432 dbname=studyGroup user=postgres password=password");
$query = "INSERT INTO studyRoom VALUES ('$_POST[StudyName]',
'$_POST[room]','$_POST[no_students]','$_POST[date]',
'$_POST[time]')";
$result = pg_query($query); 
?>